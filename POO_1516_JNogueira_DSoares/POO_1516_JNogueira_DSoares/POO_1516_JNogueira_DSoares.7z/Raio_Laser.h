#pragma once
#include "Sala.h"

class Raio_Laser :
	public Sala
{
public:
	Raio_Laser();
	~Raio_Laser();
};

