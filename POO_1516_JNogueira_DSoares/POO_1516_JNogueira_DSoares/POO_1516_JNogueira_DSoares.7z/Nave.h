#pragma once
#include "bibliotecas.h"
#include "Sala.h"
//#include "consola.h" movido para bibliotecas
#include "Propulsor.h"
#include "Beliche.h"
#include "Sala_Maquinas.h"
#include "Suporte_Vida.h"
#include "Controlo_Escudo.h"
#include "Ponte.h"

#include "Memb_Trip.h"

class Nave
{
	vector<Sala *> salas;

	int conta_propulsores = 0, pos_x, pos_y, Tamanho, distancia;
	int conta_tripulantes;
public:
	Nave();
	void DesenhaNave(int x, int y, int tamanho);
	~Nave();
	void adiciona(Sala *p);
	string toString()const;

	void Quadrado(int x, int y, Consola c, int sala, int tamanho);

	void incrementa_propulsores();
	void MoveTripulante(string nome, int room);

	int getX();	int getY();	int getTamanho();

	void imprime_salas(Consola &c);		//PERCORRE TODAS AS SALAS E IMPRIME A TRIPULA��O CONTIDA

	void incrementa_tripulantes();

	int GetConta_tripulantes();

	string getCharTrip();

	void actualiza_distancia();
};



