#include "Auto_Reparador.h"



Auto_Reparador::Auto_Reparador(int id)
{
}


Auto_Reparador::~Auto_Reparador()
{
}
