#include "Sala_Maquinas.h"



Sala_Maquinas::Sala_Maquinas(int id) :Sala(id) {}


Sala_Maquinas::~Sala_Maquinas()
{
}
