#include "Alojam_Capitao.h"



Alojam_Capitao::Alojam_Capitao(int id)
{
}


Alojam_Capitao::~Alojam_Capitao()
{
}
