#include "Membro_trip.h"



Membro_trip::Membro_trip()
{
}


Membro_trip::~Membro_trip()
{
}
