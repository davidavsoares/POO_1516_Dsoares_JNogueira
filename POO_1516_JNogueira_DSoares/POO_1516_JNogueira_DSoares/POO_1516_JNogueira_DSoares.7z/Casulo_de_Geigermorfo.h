#pragma once
#include "Xenomorfos.h"
class Casulo_de_Geigermorfo :
	public Xenomorfos
{
public:
	Casulo_de_Geigermorfo();
	~Casulo_de_Geigermorfo();
};

