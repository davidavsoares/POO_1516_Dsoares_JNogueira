#pragma once
#include "Unidade.h"
class Xenomorfos :
	public Unidade
{
public:
	Xenomorfos();
	~Xenomorfos();
};

