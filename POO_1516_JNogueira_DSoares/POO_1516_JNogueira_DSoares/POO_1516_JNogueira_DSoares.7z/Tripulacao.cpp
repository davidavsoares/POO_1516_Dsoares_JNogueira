#include "Tripulacao.h"



Tripulacao::Tripulacao(string nome): Unidade(nome)
{
}


Tripulacao::~Tripulacao()
{
}
