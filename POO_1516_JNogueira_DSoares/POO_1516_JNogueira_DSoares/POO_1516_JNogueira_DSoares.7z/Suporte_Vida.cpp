#include "Suporte_Vida.h"



Suporte_Vida::Suporte_Vida(int id) :Sala(id) {}


Suporte_Vida::~Suporte_Vida()
{
}
