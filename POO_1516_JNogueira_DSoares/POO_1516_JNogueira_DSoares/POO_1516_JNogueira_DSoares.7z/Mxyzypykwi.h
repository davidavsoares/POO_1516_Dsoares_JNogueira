#pragma once
#include "Xenomorfos.h"
class Mxyzypykwi :
	public Xenomorfos
{
public:
	Mxyzypykwi();
	~Mxyzypykwi();
};

