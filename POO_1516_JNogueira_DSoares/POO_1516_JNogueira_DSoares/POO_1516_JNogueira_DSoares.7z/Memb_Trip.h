#pragma once
#include "Tripulacao.h"

class Memb_Trip :
	public Tripulacao
{
public:
	Memb_Trip(string nome);
	~Memb_Trip();
};

