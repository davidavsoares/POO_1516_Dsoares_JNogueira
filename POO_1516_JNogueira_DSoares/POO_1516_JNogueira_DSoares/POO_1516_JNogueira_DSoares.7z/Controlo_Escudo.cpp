#include "Controlo_Escudo.h"



Controlo_Escudo::Controlo_Escudo(int id) :Sala(id) {}


Controlo_Escudo::~Controlo_Escudo()
{
}
