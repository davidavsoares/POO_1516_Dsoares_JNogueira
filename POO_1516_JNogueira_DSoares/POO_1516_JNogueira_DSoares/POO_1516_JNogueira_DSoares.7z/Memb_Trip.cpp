#include "Memb_Trip.h"



Memb_Trip::Memb_Trip(string nome) :Tripulacao(nome)
{
	
}



Memb_Trip::~Memb_Trip()
{
}
