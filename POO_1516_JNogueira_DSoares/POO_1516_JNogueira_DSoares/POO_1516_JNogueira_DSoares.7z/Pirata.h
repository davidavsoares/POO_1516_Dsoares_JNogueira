#pragma once
#include "Inimigos.h"
class Pirata :
	public Inimigos
{
public:
	Pirata();
	~Pirata();
};

