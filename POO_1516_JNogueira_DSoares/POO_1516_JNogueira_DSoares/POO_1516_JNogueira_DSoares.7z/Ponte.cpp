#include "Ponte.h"



Ponte::Ponte(int id) :Sala(id) {}


Ponte::~Ponte()
{
}
