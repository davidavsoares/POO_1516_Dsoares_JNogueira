#pragma once
#include "Xenomorfos.h"
class Geigermorfo :
	public Xenomorfos
{
public:
	Geigermorfo();
	~Geigermorfo();
};

