#pragma once
#include "Xenomorfos.h"
class Blob :
	public Xenomorfos
{
public:
	Blob();
	~Blob();
};

