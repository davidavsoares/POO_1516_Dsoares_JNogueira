#pragma once

/////////////////////Header onde se encontram as bibliotecas////////////////////////

#include <Windows.h>
#include <thread>
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <time.h>
#include <fstream>





#include "consola.h"
using namespace std;

