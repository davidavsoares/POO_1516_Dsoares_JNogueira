#pragma once
#include "Sala.h"

class Ponte : public Sala
{
public:
	Ponte(int id);
	~Ponte();
};

