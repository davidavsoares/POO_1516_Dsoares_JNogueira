#include "Beliche.h"



Beliche::Beliche(int id) :Sala(id) 
{

}


Beliche::~Beliche()
{
}
