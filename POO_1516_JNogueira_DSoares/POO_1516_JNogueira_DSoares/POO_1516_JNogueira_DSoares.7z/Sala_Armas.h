#pragma once
#include "Sala.h"
class Sala_Armas :
	public Sala
{
public:
	Sala_Armas();
	~Sala_Armas();
};

