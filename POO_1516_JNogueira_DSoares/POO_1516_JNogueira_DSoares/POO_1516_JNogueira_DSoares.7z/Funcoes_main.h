#pragma once
#include "bibliotecas.h"





//void loopmusic(HSTREAM streamHandle) {	//Fun��o que permite que o som de fundo se repita
//
//	streamHandle = BASS_StreamCreateFile(FALSE, "C:\\Users\\David Soares\\Documents\\GitHub\\POO_1516_Dsoares_JNogueira\\POO_1516_JNogueira_DSoares\\POO_1516_JNogueira_DSoares\\space-alien-ambience.flac", 0, 0, 0);
//
//	while (BASS_ChannelPlay(streamHandle, false));
//
//}

//void som_fundo()  //Fun��o que habilita a reprodu��o do som de fundo existente no jogo
//{
//	HSTREAM streamHandle;
//
//
//	BASS_Init(-1, 44100, 0, 0, NULL);
//	BASS_SetVolume(3);
//
//	thread plmusic(loopmusic, streamHandle);
//}