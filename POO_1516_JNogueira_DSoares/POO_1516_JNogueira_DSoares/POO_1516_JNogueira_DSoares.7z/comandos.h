#pragma once

#include "Interface.h"



class comandos
{
	int linhas;
	int colunas;
public:
	comandos();
	~comandos();
	void cmd(Nave &Spaceship);
	void analisa_comandos(string b, Nave &Spaceship);

};