#pragma once
#include "Unidade.h"

class Tripulacao :
	public Unidade
{
public:
	Tripulacao(string nome);
	~Tripulacao();
};

