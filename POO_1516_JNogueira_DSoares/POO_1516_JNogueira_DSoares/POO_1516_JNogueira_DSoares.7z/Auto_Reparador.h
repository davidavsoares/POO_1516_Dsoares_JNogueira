#pragma once
#include "Sala.h"
class Auto_Reparador :
	public Sala
{
public:
	Auto_Reparador();
	~Auto_Reparador();
};

