#pragma once
#include "Tripulacao.h"
class Robot :
	public Tripulacao
{
public:
	Robot();
	~Robot();
};

