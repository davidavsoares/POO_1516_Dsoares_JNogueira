#pragma once
#include "Unidade.h"
class Inimigos :
	public Unidade
{
public:
	Inimigos();
	~Inimigos();
};

